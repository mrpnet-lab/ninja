#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class RM_Pro_1_9 : Strategy
    {
        // Internal State Variables
        private double virtualSLPrice = 0.0;
        private double virtualTPPrice = 0.0;
        private bool isStealthActive = false;
        private bool hasTrailedToBreakeven = false;
        private double trailReferencePrice = 0.0; 
        private DateTime entryTime; 
        
        // Session Tracking
        private int dailyTradeCount = 0;
        private DateTime lastTradeDate = DateTime.MinValue;

        // Indicators & Data
        private EMA trendEma;
        private double currentEmaValue = 0.0; // NEW: Live-updating EMA tracker
        
        // Account Position Tracking
        private int currentPosQty = 0;
        private double currentPosPrice = 0.0;
        private MarketPosition currentPosType = MarketPosition.Flat;

        // Drawing Objects
        private HorizontalLine slLineObj;
        private HorizontalLine tpLineObj;
        private const string slTag = "SL_Line";
        private const string tpTag = "TP_Line";

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Risk Manager 1.9 - EMA Engine Fix";
                Name = "RM Pro 1.9";
                Calculate = Calculate.OnEachTick; 
                IsInstantiatedOnEachOptimizationIteration = true;
                IsUnmanaged = true; 
                
                // Standard Settings 
                StealthStopTicks = 20;
                StealthTargetTicks = 60; 
                StealthTrailTriggerTicks = 15; 
                StealthTrailDistanceTicks = 20; 

                // Volatility Settings
                UseVolatilityMode = false;
                VolStealthStopTicks = 80;        
                VolStealthTargetTicks = 160;     
                VolStealthTrailTriggerTicks = 40;
                VolBaseTrailDistanceTicks = 40;  
                VolBailoutSeconds = 15;
                VolBailoutTicks = 40;            

                // Trade Logic Filters
                MaxDailyTrades = 10;
                UseTrendFilter = false;
                TrendEmaPeriod = 200;
            }
            else if (State == State.DataLoaded)
            {
                if (UseTrendFilter)
                {
                    trendEma = EMA(TrendEmaPeriod);
                    trendEma.Plots[0].Brush = Brushes.Cyan; 
                    AddChartIndicator(trendEma);
                }
            }
            else if (State == State.Realtime)
            {
                if (Account != null) Account.PositionUpdate += OnAccountPositionUpdate;
            }
            else if (State == State.Terminated)
            {
                if (Account != null) Account.PositionUpdate -= OnAccountPositionUpdate;
            }
        }

        // THE FIX: The missing engine! This pumps the historical and live data into the indicator.
        protected override void OnBarUpdate()
        {
            if (UseTrendFilter && trendEma != null && CurrentBar >= TrendEmaPeriod)
            {
                // This constantly updates our variable on every single tick
                currentEmaValue = trendEma[0];
            }
        }

        private void OnAccountPositionUpdate(object sender, PositionEventArgs e)
        {
            if (e.Position.Instrument != Instrument) return;

            currentPosQty = e.Quantity;
            currentPosPrice = e.AveragePrice;
            currentPosType = e.MarketPosition;

            if (DateTime.Now.Date != lastTradeDate)
            {
                dailyTradeCount = 0;
                lastTradeDate = DateTime.Now.Date;
            }

            if ((currentPosType == MarketPosition.Long || currentPosType == MarketPosition.Short) && !isStealthActive)
            {
                if (dailyTradeCount >= MaxDailyTrades)
                {
                    Print("RM_Pro: Daily trade limit reached. Trade rejected.");
                    FlattenPosition();
                    return;
                }

                // THE FIX: Use the live-updated currentEmaValue 
                if (UseTrendFilter && currentEmaValue > 0)
                {
                    // Check Longs
                    if (currentPosType == MarketPosition.Long && currentPosPrice < currentEmaValue)
                    {
                        Print($"RM_Pro: Long entry rejected. Entry {currentPosPrice} is below EMA {currentEmaValue:F2}.");
                        FlattenPosition();
                        return;
                    }
                    
                    // Check Shorts
                    if (currentPosType == MarketPosition.Short && currentPosPrice > currentEmaValue)
                    {
                        Print($"RM_Pro: Short entry rejected. Entry {currentPosPrice} is above EMA {currentEmaValue:F2}.");
                        FlattenPosition();
                        return;
                    }
                }

                dailyTradeCount++;
                isStealthActive = true;
                hasTrailedToBreakeven = false;
                trailReferencePrice = 0.0;
                entryTime = DateTime.Now; 
                
                int stopTicks = UseVolatilityMode ? VolStealthStopTicks : StealthStopTicks;
                int targetTicks = UseVolatilityMode ? VolStealthTargetTicks : StealthTargetTicks;

                if (currentPosType == MarketPosition.Long)
                {
                    virtualSLPrice = currentPosPrice - (stopTicks * TickSize);
                    virtualTPPrice = currentPosPrice + (targetTicks * TickSize);
                }
                else
                {
                    virtualSLPrice = currentPosPrice + (stopTicks * TickSize);
                    virtualTPPrice = currentPosPrice - (targetTicks * TickSize);
                }
                DrawStealthLines();
            }
            else if (currentPosType == MarketPosition.Flat)
            {
                isStealthActive = false;
                virtualSLPrice = 0.0;
                virtualTPPrice = 0.0;
                RemoveDrawObject(slTag);
                RemoveDrawObject(tpTag);
                slLineObj = null;
                tpLineObj = null;
            }
        }

        private void FlattenPosition()
        {
            if (currentPosType == MarketPosition.Long)
                SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, currentPosQty, 0, 0, "", " ");
            else if (currentPosType == MarketPosition.Short)
                SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Market, currentPosQty, 0, 0, "", " ");
        }

        private double RoundToTick(double price)
        {
            return Math.Round(price / TickSize) * TickSize;
        }

        private int GetActiveTrailDistanceTicks(double currentRefPrice)
        {
            int baseDistance = UseVolatilityMode ? VolBaseTrailDistanceTicks : StealthTrailDistanceTicks;

            double profitTicks = 0;
            if (currentPosType == MarketPosition.Long)
                profitTicks = (currentRefPrice - currentPosPrice) / TickSize;
            else if (currentPosType == MarketPosition.Short)
                profitTicks = (currentPosPrice - currentRefPrice) / TickSize;

            int currentDistance = baseDistance;

            if (profitTicks >= 120) currentDistance = Math.Min(baseDistance, 10); 
            else if (profitTicks >= 80) currentDistance = Math.Min(baseDistance, 20);  

            return currentDistance;  
        }

        private void SyncInteractiveLines()
        {
            if (slLineObj != null)
            {
                double linePrice = RoundToTick(slLineObj.StartAnchor.Price);
                double internalSL = RoundToTick(virtualSLPrice);

                if (Math.Abs(linePrice - internalSL) > (TickSize / 2))
                {
                    virtualSLPrice = linePrice;

                    if (currentPosType == MarketPosition.Long)
                    {
                        if (virtualSLPrice < currentPosPrice + (1 * TickSize))
                        {
                            hasTrailedToBreakeven = false;
                            trailReferencePrice = 0.0;
                        }
                        else
                        {
                            int dynamicDist = GetActiveTrailDistanceTicks(trailReferencePrice > 0 ? trailReferencePrice : currentPosPrice);
                            trailReferencePrice = virtualSLPrice + (dynamicDist * TickSize);
                        }
                    }
                    else if (currentPosType == MarketPosition.Short)
                    {
                        if (virtualSLPrice > currentPosPrice - (1 * TickSize))
                        {
                            hasTrailedToBreakeven = false;
                            trailReferencePrice = 0.0;
                        }
                        else
                        {
                            int dynamicDist = GetActiveTrailDistanceTicks(trailReferencePrice > 0 ? trailReferencePrice : currentPosPrice);
                            trailReferencePrice = virtualSLPrice - (dynamicDist * TickSize);
                        }
                    }
                }
            }

            if (tpLineObj != null)
            {
                double linePrice = RoundToTick(tpLineObj.StartAnchor.Price);
                double internalTP = RoundToTick(virtualTPPrice);
                if (Math.Abs(linePrice - internalTP) > (TickSize / 2)) virtualTPPrice = linePrice;
            }
        }

        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
        {
            if (!isStealthActive || currentPosType == MarketPosition.Flat) return;

            SyncInteractiveLines();

            double currentAsk = GetCurrentAsk();
            double currentBid = GetCurrentBid();

            if (currentAsk == 0 || currentBid == 0) return;

            int beTriggerTicks = UseVolatilityMode ? VolStealthTrailTriggerTicks : StealthTrailTriggerTicks;

            if (currentPosType == MarketPosition.Long)
            {
                if (UseVolatilityMode && (DateTime.Now - entryTime).TotalSeconds <= VolBailoutSeconds)
                {
                    if (currentBid <= currentPosPrice - (VolBailoutTicks * TickSize))
                    {
                        isStealthActive = false; 
                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, currentPosQty, 0, 0, "", " "); 
                        return;
                    }
                }

                if (!hasTrailedToBreakeven)
                {
                    if (currentBid >= currentPosPrice + (beTriggerTicks * TickSize))
                    {
                        double bePrice = currentPosPrice + (1 * TickSize);
                        if (virtualSLPrice < bePrice) 
                        {
                            virtualSLPrice = bePrice;
                            DrawStealthLines(); 
                        }
                        hasTrailedToBreakeven = true;
                        trailReferencePrice = currentBid; 
                    }
                }
                else 
                {
                    if (currentBid > trailReferencePrice)
                    {
                        trailReferencePrice = currentBid; 
                        int activeTrailDist = GetActiveTrailDistanceTicks(trailReferencePrice);
                        double dynamicTrailPrice = trailReferencePrice - (activeTrailDist * TickSize);
                        
                        if (dynamicTrailPrice > virtualSLPrice)
                        {
                            virtualSLPrice = dynamicTrailPrice;
                            DrawStealthLines();
                        }
                    }
                }

                if (currentBid <= virtualSLPrice || currentBid >= virtualTPPrice)
                {
                    isStealthActive = false; 
                    SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, currentPosQty, 0, 0, "", " "); 
                }
            }
            else if (currentPosType == MarketPosition.Short)
            {
                if (UseVolatilityMode && (DateTime.Now - entryTime).TotalSeconds <= VolBailoutSeconds)
                {
                    if (currentAsk >= currentPosPrice + (VolBailoutTicks * TickSize))
                    {
                        isStealthActive = false; 
                        SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Market, currentPosQty, 0, 0, "", " "); 
                        return;
                    }
                }

                if (!hasTrailedToBreakeven)
                {
                    if (currentAsk <= currentPosPrice - (beTriggerTicks * TickSize))
                    {
                        double bePrice = currentPosPrice - (1 * TickSize);
                        if (virtualSLPrice > bePrice)
                        {
                            virtualSLPrice = bePrice;
                            DrawStealthLines(); 
                        }
                        hasTrailedToBreakeven = true;
                        trailReferencePrice = currentAsk; 
                    }
                }
                else
                {
                    if (currentAsk < trailReferencePrice)
                    {
                        trailReferencePrice = currentAsk; 
                        int activeTrailDist = GetActiveTrailDistanceTicks(trailReferencePrice);
                        double dynamicTrailPrice = trailReferencePrice + (activeTrailDist * TickSize);
                        
                        if (dynamicTrailPrice < virtualSLPrice)
                        {
                            virtualSLPrice = dynamicTrailPrice;
                            DrawStealthLines();
                        }
                    }
                }

                if (currentAsk >= virtualSLPrice || currentAsk <= virtualTPPrice)
                {
                    isStealthActive = false; 
                    SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Market, currentPosQty, 0, 0, "", " "); 
                }
            }
        }

        private void DrawStealthLines()
        {
            slLineObj = Draw.HorizontalLine(this, slTag, virtualSLPrice, Brushes.Crimson, DashStyleHelper.Dash, 2);
            tpLineObj = Draw.HorizontalLine(this, tpTag, virtualTPPrice, Brushes.LimeGreen, DashStyleHelper.Solid, 2);
            
            slLineObj.IsLocked = false;
            tpLineObj.IsLocked = false;
            
            ForceRefresh(); 
        }

        #region Standard Properties
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Stealth Stop (Ticks)", Description="Initial invisible stop loss", Order=1, GroupName="1. Standard Parameters")]
        public int StealthStopTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Stealth Target (Ticks)", Description="Invisible take profit", Order=2, GroupName="1. Standard Parameters")]
        public int StealthTargetTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="BE Trigger (Ticks)", Description="Ticks in profit to move to Breakeven", Order=3, GroupName="1. Standard Parameters")]
        public int StealthTrailTriggerTicks { get; set; }
        
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Trail Distance (Ticks)", Description="How closely the line follows the price after BE", Order=4, GroupName="1. Standard Parameters")]
        public int StealthTrailDistanceTicks { get; set; }
        #endregion

        #region Volatility Properties
        [NinjaScriptProperty]
        [Display(Name="1. Enable Volatility Mode", Description="Toggle for 9:30 AM open or news drops", Order=1, GroupName="2. Volatility Mode")]
        public bool UseVolatilityMode { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Vol: Stop (Ticks)", Description="Wide stop for chop (default 80 ticks/20 pts)", Order=2, GroupName="2. Volatility Mode")]
        public int VolStealthStopTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Vol: Target (Ticks)", Description="Massive target (default 160 ticks/40 pts)", Order=3, GroupName="2. Volatility Mode")]
        public int VolStealthTargetTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Vol: BE Trigger (Ticks)", Description="Ticks to trigger BE", Order=4, GroupName="2. Volatility Mode")]
        public int VolStealthTrailTriggerTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Vol: Base Trail Dist (Ticks)", Description="Starting trailing distance behind peak", Order=5, GroupName="2. Volatility Mode")]
        public int VolBaseTrailDistanceTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Vol: Bailout Time (Seconds)", Description="Time window to check for immediate reversal", Order=6, GroupName="2. Volatility Mode")]
        public int VolBailoutSeconds { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Vol: Bailout Trigger (Ticks)", Description="If it hits this loss inside Bailout Time, exit immediately", Order=7, GroupName="2. Volatility Mode")]
        public int VolBailoutTicks { get; set; }
        #endregion

        #region Strategy Filters
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Max Trades Per Day", Description="Hard cap on daily executions", Order=1, GroupName="3. Trading Filters")]
        public int MaxDailyTrades { get; set; }

        [NinjaScriptProperty]
        [Display(Name="Enable EMA Trend Filter", Description="Blocks entries against the trend", Order=2, GroupName="3. Trading Filters")]
        public bool UseTrendFilter { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="EMA Period", Description="Higher timeframe EMA for trend detection", Order=3, GroupName="3. Trading Filters")]
        public int TrendEmaPeriod { get; set; }
        #endregion
    }
}
