return require(script.Parent._Index["upliftgames_playermodule@654.1.6540477"]["playermodule"])
