# RM_Pro_Spec_1_4

## Overview
`RM_Pro_1_4` introduces **High Volatility Mode** for extreme market events (e.g., 8:30 AM CPI, 9:30 AM NY Open, 10:00 AM Consumer Sentiment). Normal tight retail stops (10-15 ticks) act as immediate liquidity fodder for Market Makers during these times.

This mode replaces static stops with wide breathing room, dynamic "profit-choking" trailers, and an emergency bailout switch to protect capital if the initial impulse is wrong.

## Suggested Volatility Configuration (Defaultly Applied)
*Remember: NQ is 4 ticks = 1 point.*
* **Vol Stop:** `80 Ticks (20 Points)`. This is wide enough to survive the initial 9:30 AM 1-minute candle whipsaw without getting tagged.
* **Vol Target:** `160 Ticks (40 Points)`. In high vol, if you catch the trend, you get paid heavily (1:2 R/R).
* **Vol BE Trigger:** `40 Ticks (10 Points)`. 

## Feature 1: The "Smart Choke" Dynamic Trailing
When `UseVolatilityMode` is checked, the continuous trailer changes its behavior mathematically as you become more profitable. 
Instead of staying a flat 15 ticks behind the price, it actively tightens to prevent giving back massive momentum spikes:
1. **Initial Phase (0 to +20 points profit):** The trail stays a safe **10 points** (`VolBaseTrailDistanceTicks = 40`) behind the peak to avoid being shaken out by pullbacks.
2. **Tier 1 Tightening (+20 points profit):** Once your profit crosses 80 ticks, the algorithm realizes a massive move is underway. It cuts the trailing distance in half to **5 points** (20 ticks).
3. **Tier 2 Tightening (+30 points profit):** If profit crosses 120 ticks, the algorithm goes into pure defense. It tightens the trail to just **2.5 points** (10 ticks) behind the peak. If the market hesitates or wicks back, you secure a massive win immediately.

*Note: If you manually drag the line, the system flawlessly recalibrates its dynamic distance relative to where you dropped it.*

## Feature 2: The Bailout Switch (The Panic Button)
Wide stops are great for avoiding wicks, but catastrophic if you are genuinely on the wrong side of an aggressive trend.
* **Logic:** The strategy records the exact second you enter the trade. 
* **The Check:** If the trade drops to `-10 Points (-40 Ticks)` within the first `15 Seconds` of opening the trade, the algorithm knows the momentum is instantly rejecting your entry.
* **The Action:** Instead of waiting to hit the full 80-tick Stop Loss, it fires a Market Order to BAIL OUT immediately, saving you 40 ticks of unnecessary loss.
