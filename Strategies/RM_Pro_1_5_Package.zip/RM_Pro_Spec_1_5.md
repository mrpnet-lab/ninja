# RM_Pro_Spec_1_5

## The Prop Firm Paranoia Update
This version clones `RM_Pro_1_4` and addresses critical concerns regarding prop firm order monitoring (e.g., TakeProfit Trader).

### The Local UI vs. The Broker Reality
There is a fundamental misconception in how NinjaTrader displays data versus what the prop firm actually sees:

1. **The "Strategy" Column:** In your NinjaTrader 'Orders' tab, you will *always* see "RM Pro 1.5" listed next to the order. **TakeProfit Trader CANNOT see this.** This text is rendered directly from your local PC's internal NinjaTrader database (`NinjaTrader.sdf`). Rithmic (the data feed) only receives a standard FIX API connection request. They know you are using NinjaTrader, but they have absolutely no visibility into your local C# file names or your local UI grids.
2. **The "Name" Column:** When an empty order is submitted, NinjaTrader's local UI automatically defaults to writing "Sell" or "Buy to cover" to be helpful to the user.

### What Changed in v1.5: The Mask
Despite the broker not seeing your local UI, we have updated the C# code to mask the Order Name completely, mimicking a purely blank manual Chart Trader click.
* **The Trick:** We updated the `SubmitOrderUnmanaged` commands. Instead of passing an empty string `""` (which NT8 overrides with "Sell"), we now pass a single blank space `" "`. 
* **The Result:** NinjaTrader's UI accepts the space as a valid custom name. Your Executions and Orders tabs will now show completely blank fields under the Name column, identical to a raw manual entry.

*Note: You cannot blank out the "Strategy" column locally without breaking NinjaTrader's ability to run the code. But rest assured, the prop firm risk desk cannot see that column.*
